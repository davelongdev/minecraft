execute if score @s tut_pp matches 0 run scoreboard players set @s tut_pm 0
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "━━ Quest 5 of 12: The Forward Slash ━━", "font": "minecraft:uniform", "color": "gold", "bold": true}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "", "font": "minecraft:uniform"}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "The ", "font": "minecraft:uniform"}, {"text": "/", "font": "minecraft:uniform", "color": "aqua", "bold": true}, {"text": " tells Minecraft: this is a command, not chat. Type this and press Enter:", "font": "minecraft:uniform"}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "", "font": "minecraft:uniform"}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "    ", "font": "minecraft:uniform"}, {"text": "/effect give @s glowing", "font": "minecraft:uniform", "color": "aqua", "bold": true}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "", "font": "minecraft:uniform"}]
execute if score @s tut_pp matches 0 run tellraw @s [{"text": "", "font": "minecraft:uniform", "color": "white"}, {"text": "Are you glowing? If so, you've completed the quest! ", "font": "minecraft:uniform"}, {"text": "The next quest starts as soon as you've done it.", "font": "minecraft:uniform", "color": "green", "bold": true}]
execute if score @s tut_pp matches 0 run scoreboard players set @s tut_pp -1
